
// Obtener palabra compartida desde la ventana principal
let palabra = window.opener.palabraCompartida.toLowerCase();

// Variables de estado del juego
let caracteresLetra = palabra.length;
//console.log(caracteresLetra);
let letrasAcertadas = Array(palabra.length).fill("_"); 
let fallosRestantes = (caracteresLetra/2)+1; 
let tiempoPorLetra = (caracteresLetra*10)/3;  //Parece tonto esto, pero si no lo pongo el tiempo restante no funciona bien
let tiempoRestante = (caracteresLetra*10)/3; 
let temporizador = null;

// Elementos del DOM
let contadorFallos = document.getElementById("contadorFallos");
let mostrarPalabra = document.getElementById("mostrarPalabra");
let mostrarPalabraOculta = document.getElementById("mostrarPalabraOculta");
let tiempoTexto = document.getElementById("tiempoRestanteTexto");
let fallosUsuario = document.getElementById("FallosDelUsuario");
let letrasEscribir = document.getElementById("escribir");
let botonComprobar = document.getElementById("comprobarLetra");
let botonInicio = document.getElementById("inicioJuego");
let RecuentoJuegos= document.getElementById("RecuentoJuegos");
let volverJUGAR = document.getElementById("volverJUGAR");

// Mostrar palabra oculta al pulsar el boton
document.getElementById("verPalabraOculta").onclick = () => {
    mostrarPalabraOculta.innerHTML = palabra;
};

/** 
 * Funciones independientes
 * */ 
function actualizarPalabraMostrada() { //actualiza la palabra que se esta mostrando al ir cambiando _ por letras
    mostrarPalabra.innerHTML = letrasAcertadas.join(" ");
}

function actualizarFallos() { //Actualiza el contador de fallos
    contadorFallos.innerHTML = fallosRestantes;
}

function actualizarTiempoTexto() { //actualiza el tiempo restante por letra
    tiempoTexto.innerHTML = "Tiempo restante:"+tiempoRestante+"segundos";
}

//Fnccion neceesaria para ir controlando el temporizador

function iniciarTemporizador() {
    let fallosRestantes = ((palabra.length/2)+1); 

    clearInterval(temporizador);
    tiempoRestante = tiempoPorLetra;
    actualizarTiempoTexto();

    temporizador = setInterval(() => {
        tiempoRestante--;
        actualizarTiempoTexto();

        if (tiempoRestante <= 0) {
            clearInterval(temporizador);

            // Contamos como fallo automático y quitamos un fallor
            fallosRestantes--;
            actualizarFallos();
            fallosUsuario.innerHTML += "<br> Tiempo agotado";

            // Reiniciamos el temporizador para la siguiente letra
            iniciarTemporizador();

            // Verificar derrota, si no quedan fallos directamente se ha perdido 
            if (fallosRestantes <= 0) {
                alert("¡Has perdido!, tu palabra era:" + palabra);
                clearInterval(temporizador);
            }
        }
    }, 1000);
}

//let ganar;

//Funcion para ir comprobando las letras que se introducen 
function comprobarLetra() {
    let letra = letrasEscribir.value.toLowerCase();
    letrasEscribir.value = "";

    // Validamos la letra con una expresion regular
    if (!letra || letra.length !== 1 || !/^[a-zñ]$/i.test(letra)) return;

    let acierto = false;

    

    // Recorremos la palabra para ir cambiando _ por la letra
    palabra.split("").forEach((char, i) => {
        if (char === letra && letrasAcertadas[i] === "_") {
            letrasAcertadas[i] = letra;
            acierto = true;
        }
    });

    if (acierto) { //correcta, se actualiza el campo de los _
        actualizarPalabraMostrada();
    } else { //Incorrecta, quitamos un fallo y lo actualizamos
        fallosRestantes--;
        actualizarFallos();
        fallosUsuario.innerHTML += "<br> La letra "+letra+" no es correcta.";
    }

    iniciarTemporizador(); // Reinicia el tiempo para la siguiente letra

    // Verificar victoria
    if (!letrasAcertadas.includes("_")) {
        clearInterval(temporizador);
        alert("¡Has ganado!");
        ganar="has ganado";
        botonComprobar.disabled = true;
        letrasEscribir.disabled = true;
    }

    // Verificar derrota
    if (fallosRestantes <= 0) {
        clearInterval(temporizador);
        alert("¡Has perdido!, la palabra era:" + palabra);
        ganar="has perdidio";
        botonComprobar.disabled = true;
        letrasEscribir.disabled = true;
    }
}

//let contadorPartidas=0;

// Para que empiece a funcionar todo despues de darle al boton de inicio 
botonInicio.onclick=function(){
letrasAcertadas = Array(palabra.length).fill("_");
    fallosRestantes = (caracteresLetra/2)+1; ;
    botonComprobar.disabled = false;
    letrasEscribir.disabled = false;
    fallosUsuario.textContent = "";
    actualizarPalabraMostrada();
    actualizarFallos();
    iniciarTemporizador();

    // //No me va a funcionar porque si quiero iniciar otra partida tengo que volver a otra pagina principal y no se como guardarlo al moverme entre pantallas
    //seria hacer un contador de partidas, la palabra ir mostrandola y el tiempo ir acumulandolo en una variable cad avez que se averigue una palabra

    // RecuentoJuegos.innerHTML="Partida:"+contadorPartidas+",Palabra"+palabra+","+ganar;
    // contadorPartidas++;
}

// volverJUGAR.onclick=function(){
//      window.open("index.html");
// }

// Comprobar letra al hacer clic
botonComprobar.addEventListener("click", comprobarLetra);



